import os 

def open_website(url):
    # Construct the appropriate command based on the operating system
    if os.name == 'nt':  # For Windows
        os.system(f'start {url}')
    elif os.name == 'posix':  # For Linux, macOS, etc.
        os.system(f'xdg-open {url}')
    else:
        raise Exception("Unsupported operating system")




def Argiros_Spotify():
    open_website('https://open.spotify.com/artist/5YquORfLTx6nWMlBzJstx7')


def Rouvas_Spotify():
    open_website('https://open.spotify.com/artist/0VuyN0xzSqykiDB2MxihTe')
    
