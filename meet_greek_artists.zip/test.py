import customtkinter
from tkinter import *
from PIL import Image, ImageTk


root = customtkinter.CTk()
root.geometry("1100x800")



tabs = customtkinter.CTkTabview(master=root, width=1100, height=750)
artist_text = tabs.add("Text")
artist_photo = tabs.add("Photos")
artist_listen = tabs.add("Listen/Plays")


class MyTabView(customtkinter.CTkTabview):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        # create tabs
        self.add("Text")
        self.add("Photos")
        self.add("Listen/Plays")

        # add widgets on tabs
        self.label = customtkinter.CTkLabel(master=self.tab("Text"))
        self.label.grid(row=0, column=0, padx=20, pady=10)
        self.label = customtkinter.CTkLabel(master=self.tab("Photos"))
        self.label.grid(row=0, column=0, padx=20, pady=10)
        self.label = customtkinter.CTkLabel(master=self.tab("Listen/Plays"))
        self.label.grid(row=0, column=0, padx=20, pady=10)
        


def Clear():
    tabs.delete(artist_text)
    tabs.delete(artist_photo)
    tabs.delete(artist_listen)
 
def Rouvas():
    Clear()
    MyTabView(master=root)
    tabs.place(x=100,y=100)
    rouvas_text.place(x=0,y=0)
    image_rouvas_res.place(x=0,y=0)
    
    
    
def Argiros():
    Clear()
    MyTabView(master=root)
    tabs.place(x=100,y=100)
    argiros_text.place(x=0,y=0)
    image_argiros_res.place(x=0,y=0)




rouvas = customtkinter.CTkButton(master=root, text="Sakis Rouvas", command=Rouvas)
rouvas_text = customtkinter.CTkLabel(master=artist_text,text="Born and raised in the island of Corfu, Sakis Rouvas started his music career in 1991, at the Thessaloniki Song Festival. \nSince then, he has steadily been at the top of the Greek music scene and show-biz with numerous distinctions among different fields, \nas he has received the Best New Singer, Best Song and the “Karolos Koun” Award for Best Stage Performance, \nas well as many other national and international awards.\nHis multitalented personality has been demonstrated through his leading roles in cinema, ancient drama and Hollywood movies, \nas well as through his participation in popular TV shows and large-scale events, including the 2004 Athens Olympics Closing Ceremony and the \nEurovision Song Contest, \nwhere he successfully represented Greece in 2004 and 2009. \nParallel to his career, Sakis has participated in several initiatives that aim to raise awareness for the protection of the environment \nand has demonstrated a long-term commitment to supporting children in need, while being himself a caring father of four.", font=("Arial", 17))
image_rouvas = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/rouvas.png"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/rouvas.png"), size=(400, 400))
image_rouvas_res = customtkinter.CTkLabel(master=artist_photo,text=" ", image=image_rouvas)
rouvas_label = customtkinter.CTkLabel(master=artist_text,text="Sakis Rouvas", font=("Arial", 30, "bold"))


argiros = customtkinter.CTkButton(master=root, text="Konstantinos Argiros", command=Argiros)
argiros_text = customtkinter.CTkLabel(master=artist_text, text="argiros", font=("Arial", 17))
image_argiros = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/argiros.png"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/argiros.png"), size=(350, 400))
image_argiros_res = customtkinter.CTkLabel(master=artist_photo, text=" ", image=image_argiros)
argiros_label = customtkinter.CTkLabel(master = artist_text, text="Konstantinos Argiros", font=("Arial", 30, "bold"))

rouvas.place(x=0,y=0)
argiros.place(x=0,y=30)

root.mainloop()
