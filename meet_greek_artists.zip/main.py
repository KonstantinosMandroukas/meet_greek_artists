'''libraries'''
import customtkinter
import tkinter as tk
from PIL import Image, ImageTk
from time import *
import os
from spotify import *
from youtube import *







''' app apearance'''

customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("dark-blue")


''' app layout '''

root = customtkinter.CTk()
root.title("Meet greek artists")
root.geometry("1500x900")
root.resizable(False, False)

tabs = customtkinter.CTkTabview(master=root, width=1100, height=750)
artist_text = tabs.add("Text")
artist_photo = tabs.add("Photos")
artist_listen = tabs.add("Listen/Plays")


# def MyTabView(artist_text, artist_photo, artist_listen):
#     tabs = customtkinter.CTkTabview(master=root, width=1100, height=750)
#     artist_text = tabs.add("Text")
#     artist_photo = tabs.add("Photos")
#     artist_listen = tabs.add("Listen/Plays")
    
    





''' functions'''



def Rouvas():
    rouvas_spotify.place(x=0, y=30)
    root_label.place_forget()
    tabs.place(x=300, y=100)
    rouvas_text.place(x=10, y = 200)
    image_rouvas_res.place(x=0, y = 10)
    image_bezos_res.place_forget()
    rouvas_label.place(x=450, y= 100)
    argiros_text.place_forget()
    image_argiros_res.place_forget()
    argiros_label.place_forget()
    bezos_text.place_forget()
    bezos_label.place_forget()
    argiros_spotify.place_forget()
    go.place_forget()
    visit.place_forget()
    visit_spot.place(x=0, y=0)
    visit_yt.place(x=300, y=0)
    rouvas_youtube.place(x=300, y=30)
    argiros_youtube.place_forget()
    
     
    
def Argiros():
    argiros_spotify.place(x=0,y=0)
    root_label.place_forget()
    tabs.place(x=300, y=100)
    argiros_text.place(x=500, y=300)
    image_argiros_res.place(x=200, y=200)
    image_bezos_res.place_forget()
    argiros_label.place(x=400, y= 100)
    rouvas_text.place_forget()
    image_rouvas_res.place_forget()
    rouvas_label.place_forget()
    bezos_text.place_forget()
    bezos_label.place_forget()
    rouvas_spotify.place_forget()
    go.place_forget()
    visit.place_forget()
    rouvas_youtube.place_forget()


def Select_artist_category(category):
    if category == "Singers":
        '''place'''
        rouvas.grid(padx=3, pady=0)
        argiros.grid(padx=3, pady=10)
        # checkBox_for_rouvas.grid(padx=150, pady=203)
        # checkBox_for_argiros.grid(padx=150, pady=253)
        '''place forget'''
        bezos.grid_forget()
        seferlis.grid_forget()
        bezos_text.place_forget()
        image_bezos_res.place_forget()
        bezos_label.place_forget()
        option_2.place_forget()
        option_1.place_forget()
        root_label.place_forget()
        go.place_forget()
        visit.place_forget()
        tabs.place_forget()
        tabs.place(x=300, y=100)
        argiros_youtube.place_forget()
        rouvas_youtube.place_forget()
        tabs.place_forget()
    elif category == "Actors":
        '''place'''
        # tabs.place(x=300, y=100)
        bezos.grid(padx=3, pady=0)
        seferlis.grid(padx=3, pady=10)
        # checkBox_for_bezos.grid(padx=150, pady=203)
        '''place forget'''
        argiros_text.place_forget()
        image_argiros_res.place_forget()
        rouvas_text.place_forget()
        image_rouvas_res.place_forget()
        rouvas.grid_forget()
        argiros.grid_forget()
        checkBox_for_rouvas.grid_forget()
        checkBox_for_argiros.grid_forget()
        rouvas_label.place_forget()
        argiros_label.place_forget()
        option_2.place_forget()
        option_1.place_forget()
        root_label.place_forget()
        rouvas_spotify.place_forget()
        argiros_spotify.place_forget()
        go.place_forget()
        visit.place_forget()
        tabs.place_forget()
        argiros_youtube.place_forget()
        rouvas_youtube.place_forget()
        # tabs.place(x=300, y=100)
        
        
def Bezos():
    '''place forget'''
    # rouvas_label.place_forget()
    # rouvas_text.place_forget()
    # image_rouvas_res.place_forget()
    # argiros_label.place_forget()
    # argiros_text.place_forget()
    # image_argiros_res.place_forget()
    # argiros_spotify.place_forget()
    # rouvas_spotify.place_forget()
    # seferlis_label.place_forget()
    # seferlis_text.place_forget()
    # image_seferlis_res.place_forget()
    # argiros_youtube.place_forget()
    # rouvas_youtube.place_forget()
    # tabs.
    # sleep(3)
    if tabs.tab("Text") and tabs.tab("Photos") and tabs.tab("Listen/Plays"):
        tabs.delete("Text")
    '''place'''
    tabs.place(x=300, y=100)
    bezos_text.place(x=10, y=100)
    go.place(x=100, y=100)
    image_bezos_res.place(x=0, y=0)
    bezos_label.place(x=0, y=0)
    visit.place(x=0, y=0)

    

def Seferlis():
    '''place forget'''
    # rouvas_label.place_forget()
    # rouvas_text.place_forget()
    # image_rouvas_res.place_forget()
    # argiros_label.place_forget()
    # argiros_text.place_forget()
    # image_argiros_res.place_forget()
    # bezos_text.place_forget()
    # image_bezos_res.place_forget()
    # bezos_label.place_forget()
    # visit.place(x=0, y=0)
    # argiros_spotify.place_forget()
    # rouvas_spotify.place_forget()
    # argiros_youtube.place_forget()
    # rouvas_youtube.place_forget()
    tabs.place_forget()
    '''place'''
    tabs.place(x=300, y=100)
    seferlis_text.place(x=0, y=0)
    image_seferlis_res.place(x=0, y=0)
    seferlis_label.place(x=0, y=0)
    go.place(x=100, y=100)
    





def Set_Themes(choise):
    customtkinter.set_appearance_mode(choise)






def Search():
    tabs.place_forget()
    root_label.place_forget()
    search_text = search.get().lower()
    clear.place(x=10, y=20)

    option_1.place(x=250, y=100)
    option_2.place(x=250, y=180)
    
    def Go():
        
        option_1.place_forget()
        option_2.place_forget()
        
        choise = search_text
        if choise == "sakis rouvas" or choise == "rouvas":
            Rouvas()
        elif choise == "konstantinos argiros" or choise == "argiros":
            Argiros()
        elif choise == "giannis bezos" or choise == "bezos":
            Bezos()
        elif choise == "markos seferlis" or choise == "seferlis":
            Seferlis()     

    if "sakis rouvas" in search_text or "rouvas" in search_text:
        label_argiros.place_forget()
        label_rouvas.place(x=1, y=1)
        label_bezos.place_forget()
        label_seferlis.place_forget()
        go = customtkinter.CTkButton(master=option_1, text="Go", command=Go)
        go.place(x=850, y=1)
    elif "konstantinos argiros" in search_text or "argiros" in search_text:
        label.place_forget()
        label_2.place_forget()
        label_rouvas.place_forget()
        label_argiros.place(x=1, y=1)
        label_seferlis.place_forget()
        go = customtkinter.CTkButton(master=option_1, text="Go", command=Go)
        go.place(x=850, y=1)
    elif "giannis bezos" in search_text or "bezos" in search_text:
        label.place_forget()
        label_2.place_forget()
        label_argiros.place_forget()
        label_rouvas.place_forget()
        label_bezos.place(x=1, y=1)
        label_seferlis.place_forget()
        go = customtkinter.CTkButton(master=option_1, text="Go", command=Go)
        go.place(x=850, y=1)
    elif "markos seferlis" in search_text or "seferlis" in search_text:
        label.place_forget()
        label_2.place_forget()
        label_bezos.place_forget()
        label_rouvas.place_forget()
        label_argiros.place_forget()
        label_seferlis.place(x=1, y=1)
        go = customtkinter.CTkButton(master=option_1, text="Go", command=Go)
        go.place(x=850, y=1)
    else:
        label_argiros.place_forget()
        label_rouvas.place_forget()
        label_bezos.place_forget()
        label.place(x=1, y=1)
        label_2.place(x=1, y=1)
        
        



def Go():
    open_website("https://www.more.com/")


        
        
def Clear():
    search.delete(0, tk.END)
    option_1.place_forget()
    option_2.place_forget()

    



def Home_button():
    root_label.place(x=650, y=350)
    tabs.place_forget()
    bezos.grid_forget()
    rouvas.grid_forget()
    argiros.grid_forget()
    seferlis.grid_forget()




'''general '''



frame = customtkinter.CTkFrame(master=root, width=250, height=900) 
frame.place(x=0, y=0)

scrolable_frame = customtkinter.CTkScrollableFrame(master=frame, width=200, height=500)
scrolable_frame.place(x=0, y=230)

select_label = customtkinter.CTkLabel(master=frame, text="Select an artist", font=("Arial", 20)) 
select_label.place(x=30, y= 2)

root_label = customtkinter.CTkLabel(master=root, text="Select an artist and learn more about him/her", font=("Arial", 20)) 
root_label.place(x=650, y=350)

home_button = customtkinter.CTkButton(master=frame, text="Home", command=Home_button)
home_button.place(x=3, y = 100)

search_frame = customtkinter.CTkFrame(master=root, width=800, height=80)
search_frame.place(x=450, y=10)

search = customtkinter.CTkEntry(master=search_frame, placeholder_text="Search an artist (Example: 'Konstantinos Argiros')", width=310, height=40, corner_radius=45)
search.place(x=250, y=15)

search_button = customtkinter.CTkButton(master= search_frame, text="Search", command=Search)
search_button.place(x= 600, y=23)

set_theme_values = ["Light", "Dark", "System"]
set_theme = customtkinter.CTkComboBox(master=frame, values=set_theme_values , command=Set_Themes)
set_theme.place(x=3, y=800)

select_artist_category_values = ["Actors", "Singers"]
select_artist_category = customtkinter.CTkComboBox(master=frame, values=select_artist_category_values, command=Select_artist_category)
select_artist_category.place(x=3, y=150)

clear = customtkinter.CTkButton(master=search_frame, text="Clear", command=Clear)


option_1 = customtkinter.CTkFrame(master = root, width=1000, height=50)
option_2 = customtkinter.CTkFrame(master = root, width=1000, height=50)

label = customtkinter.CTkLabel(master=option_1, text="No results found.")
label_2 = customtkinter.CTkLabel(master=option_2, text="No results found.")

spotify_image = customtkinter.CTkImage(dark_image= Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/spotify.png"), light_image= Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/spotify.png"), size=(200, 200))
youtube_image = customtkinter.CTkImage(dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/youtube.png"), light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/youtube.png"), size=(200, 200))

visit_spot = customtkinter.CTkLabel(master=artist_listen, text="Visit Spotify:", font=("Arial", 25, "bold"))
visit_yt = customtkinter.CTkLabel(master=artist_listen, text="Visit YouTube", font=("Arial", 25, "bold"))


go = customtkinter.CTkButton(master=artist_listen, text="Go", command=Go)

visit = customtkinter.CTkLabel(master=artist_listen, text="You can visit 'more.com' to learn more \nabout current plays where the artist might be performing on.")



'''artist buttons'''

#actors
bezos = customtkinter.CTkButton(master=scrolable_frame, text="Giannis Bezos", command=Bezos)
bezos_text = customtkinter.CTkLabel(master=artist_text, text="Bezos")
image_bezos = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/bezos.png"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/bezos.png"), size=(800, 450))
image_bezos_res = customtkinter.CTkLabel(master= artist_photo, text=" ", image=image_bezos)
bezos_label = customtkinter.CTkLabel(master=artist_text, text="Giannis Bezos", font=("Aria", 30, "bold"))
checkBox_for_bezos = customtkinter.CTkCheckBox(master=scrolable_frame, text="Done")
label_bezos = customtkinter.CTkLabel(master=option_1, text="Are you looking for: Giannis Bezos")

seferlis = customtkinter.CTkButton(master=scrolable_frame, text="Markos Seferlis", command=Seferlis)
seferlis_text = customtkinter.CTkLabel(master=artist_text, text="Seferlis")
image_seferlis = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/seferlis.jpg"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/seferlis.jpg"), size=(1200, 700))
image_seferlis_res = customtkinter.CTkLabel(master=artist_photo, text=" ", image=image_seferlis)
seferlis_label = customtkinter.CTkLabel(master=artist_text, text="Markos Seferlis", font=("Arial", 30, "bold"))
checkBox_for_seferlis = customtkinter.CTkCheckBox(master=scrolable_frame, text="Done")
label_seferlis = customtkinter.CTkLabel(master=option_1, text="Are you looking for: Markos Seferlis")

#singers

rouvas = customtkinter.CTkButton(master=scrolable_frame, text="Sakis Rouvas", command=Rouvas)
rouvas_text = customtkinter.CTkLabel(master=artist_text, text="Born and raised in the island of Corfu, Sakis Rouvas started his music career in 1991, at the Thessaloniki Song Festival. \nSince then, he has steadily been at the top of the Greek music scene and show-biz with numerous distinctions among different fields, \nas he has received the Best New Singer, Best Song and the “Karolos Koun” Award for Best Stage Performance, \nas well as many other national and international awards.\nHis multitalented personality has been demonstrated through his leading roles in cinema, ancient drama and Hollywood movies, \nas well as through his participation in popular TV shows and large-scale events, including the 2004 Athens Olympics Closing Ceremony and the \nEurovision Song Contest, \nwhere he successfully represented Greece in 2004 and 2009. \nParallel to his career, Sakis has participated in several initiatives that aim to raise awareness for the protection of the environment \nand has demonstrated a long-term commitment to supporting children in need, while being himself a caring father of four.", font=("Arial", 17))
image_rouvas = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/rouvas.png"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/rouvas.png"), size=(400, 400))
image_rouvas_res = customtkinter.CTkLabel(master=artist_photo, text=" ", image=image_rouvas)
rouvas_label = customtkinter.CTkLabel(master = artist_text, text="Sakis Rouvas", font=("Arial", 30, "bold"))
label_rouvas = customtkinter.CTkLabel(master=option_1, text="Are you looking for: Sakis Rouvas")
checkBox_for_rouvas = customtkinter.CTkCheckBox(master=scrolable_frame, text="Done", width=10, height=10)
rouvas_spotify = customtkinter.CTkButton(master=artist_listen, text=" ", command=Rouvas_Spotify, width=-1000, height=-1000, image=spotify_image, fg_color="#153f25", hover_color="#1d5833", corner_radius=100)
rouvas_youtube = customtkinter.CTkButton(master=artist_listen, text=" ", image=youtube_image, fg_color="#9c2f21", hover_color="#B54537", corner_radius=100)


argiros = customtkinter.CTkButton(master=scrolable_frame, text="Konstantinos Argiros", command=Argiros)
argiros_text = customtkinter.CTkLabel(master=artist_text, text="argiros", font=("Arial", 17))
image_argiros = customtkinter.CTkImage(light_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/argiros.png"), dark_image=Image.open("C:/Users/konma/Documents/vs code-programming/meet greek artists/artist_images/argiros.png"), size=(350, 400))
image_argiros_res = customtkinter.CTkLabel(master=artist_photo, text=" ", image=image_argiros)
argiros_label = customtkinter.CTkLabel(master = artist_text, text="Konstantinos Argiros", font=("Arial", 30, "bold"))
checkBox_for_argiros = customtkinter.CTkCheckBox(master=scrolable_frame, text="Done")
label_argiros = customtkinter.CTkLabel(master=option_1, text="Are you looking for: Konstantinos Argiros")
argiros_spotify = customtkinter.CTkButton(master=artist_listen, text=" ", command=Argiros_Spotify, width=-1000, height=-1000, image=spotify_image, fg_color="#153f25", hover_color="#1d5833", corner_radius=100)
argiros_youtube = customtkinter.CTkButton(master=artist_listen, text=" ", image=youtube_image, fg_color="#9c2f21", hover_color="#B54537", corner_radius=100)










root.mainloop()