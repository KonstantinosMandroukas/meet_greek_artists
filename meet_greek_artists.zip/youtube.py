import os


def open_website(url):
    # Construct the appropriate command based on the operating system
    if os.name == 'nt':  # For Windows
        os.system(f'start {url}')
    elif os.name == 'posix':  # For Linux, macOS, etc.
        os.system(f'xdg-open {url}')
    else:
        raise Exception("Unsupported operating system")



def Rouvas_Yt():
    open_website('https://www.youtube.com/channel/UCgOsNQKDXc7YDHAUyxSlY5g')
    
def Argiros_Yt():
    open_website('https://www.youtube.com/@ArgirosTv')
    